/* Create database */

CREATE DATABASE `vikingacademy` /*!40100 COLLATE 'latin1_swedish_ci' */;
USE `vikingacademy`;

/* End Create database */

/* Create admins table */

CREATE TABLE `admins` (
	`ID` INT(11) NOT NULL AUTO_INCREMENT,
	`Name` VARCHAR(50) NOT NULL DEFAULT '0',
	`Role` ENUM('Owner','Manager','Sales') NOT NULL DEFAULT 'Sales',
	`Phone` VARCHAR(50) NOT NULL DEFAULT '0',
	`Email` VARCHAR(50) NOT NULL DEFAULT '0',
	`Password` VARCHAR(50) NOT NULL DEFAULT '0',
        `Image` VARCHAR(50) NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`)
)
ENGINE=InnoDB
AUTO_INCREMENT= 1
;

/* Populate admins table */

INSERT INTO admins (Name, Role, Phone, Email, Password, Image) VALUES ('Odin Borrsson', 'Owner', '051-111-0000', 'bodin@viku.org', 'a098a8cbb0b829014c6b78d9d2ba9daa55b6bdaf', 'admin1.jpg');
INSERT INTO admins (Name, Role, Phone, Email, Password, Image) VALUES ('Thor Odinsson', 'Manager', '051-111-1111', 'othor@viku.org', '2de2452ee8c5720b7e694a374d5a36aa05f4f4a0', 'admin2.jpg');
INSERT INTO admins (Name, Role, Phone, Email, Password, Image) VALUES ('Bragi Odinsson', 'Manager', '051-111-1112', 'obragi@viku.org', '2e79364dd51bd186c1d52e210530108d0479b97b', 'admin3.jpg');
INSERT INTO admins (Name, Role, Phone, Email, Password, Image) VALUES ('Baldur Odinsson', 'Manager', '051-111-1113', 'obaldur@viku.org', '25df7e7582bb6e27df7bf761f3b756172722ad4a', 'admin4.jpg');
INSERT INTO admins (Name, Role, Phone, Email, Password, Image) VALUES ('Freyr Njordsson', 'Sales', '051-111-2221', 'nfreyr@viku.org', 'b940e02156e4646e574385d23c48927dd5b7a26b', 'admin5.jpg');
INSERT INTO admins (Name, Role, Phone, Email, Password, Image) VALUES ('Freya Njordsdotir', 'Sales', '051-111-2222', 'nfreya@viku.org', '34032fb55daf8751790291bbb5870564ea0ce69e', 'admin6.jpg');
INSERT INTO admins (Name, Role, Phone, Email, Password, Image) VALUES ('Gerdr Njordsdotir', 'Sales', '051-111-2223', 'ngerdr@viku.org', '22ad5b51854c36f519fdac3fa1b432f1a805851c', 'admin7.jpg');

/* End Create admins table */

/* Create courses table */

CREATE TABLE `courses` (
	`ID` INT(1) NOT NULL AUTO_INCREMENT,
	`Name` VARCHAR(50) NOT NULL DEFAULT '0',
	`Description` VARCHAR(50) NOT NULL DEFAULT '0',
	`Image` VARCHAR(50) NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`)
)
ENGINE=InnoDB
AUTO_INCREMENT= 1
;

/* Populate courses table */

INSERT INTO courses (Name, Description, Image) VALUES ('Viking History 101', 'History of the Vikings from Lindisfarne to Paris', 'course1.jpg');
INSERT INTO courses (Name, Description, Image) VALUES ('Viking History 102', 'Ragnar Lothbrok and the Great Heathen Army', 'course2.jpg');
INSERT INTO courses (Name, Description, Image) VALUES ('Viking Culture 201', 'Norse Mythology - from Odin to Siegfried', 'course3.jpg');
INSERT INTO courses (Name, Description, Image) VALUES ('Viking Culture 202', 'Norse Mythology - from Ragnarok to Revelations', 'course4.jpg');
INSERT INTO courses (Name, Description, Image) VALUES ('Viking Society 301', 'Status and leadership in Viking society', 'course5.jpg');
INSERT INTO courses (Name, Description, Image) VALUES ('Viking Society 302', 'Women and family structure in Viking society', 'course6.jpg');

/* End Create courses table */

/* Create students table */

CREATE TABLE `students` (
	`ID` INT(11) NOT NULL AUTO_INCREMENT,
	`Name` VARCHAR(50) NOT NULL DEFAULT '0',
	`Phone` VARCHAR(50) NOT NULL DEFAULT '0',
	`Email` VARCHAR(50) NOT NULL DEFAULT '0',
	`Image` VARCHAR(50) NOT NULL DEFAULT '0',
	PRIMARY KEY (`ID`)
)
ENGINE=InnoDB
AUTO_INCREMENT= 1
;

/* Populate students table */

INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Marvin Finkelstein', '050-485-2039', 'fmarvin@gmail.com', 'student1.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Flippy Xandu', '052-304-3947', 'xflippy@gmail.com', 'student2.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Archie Sniggets', '053-922-3345', 'sarchie@gmail.com', 'student3.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Fuji Minuli', '054-334-3009', 'mfuji@gmail.com', 'student4.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Phil Bochs', '052-665-3004', 'bphil@gmail.com', 'student5.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Gary Garcia', '054-873-3344', 'ggary@gmail.com', 'student6.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Nathan Spikes', '053-201-9889', 'snathan@gmail.com', 'student7.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Barney Fuffo', '052-223-2994', 'fbarney@gmail.com', 'student8.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Lazlo Dimpler', '054-256-2256', 'dlazlo@gmail.com', 'student9.jpg');
INSERT INTO students	(Name, Phone, Email, Image) VALUES ('Sorr Loozer', '053-209-3287', 'lsorr@gmail.com', 'student10.jpg');

/* End Create students table */

/* Create registry table */

CREATE TABLE `registry` (
	`Serial` INT(11) NOT NULL AUTO_INCREMENT,
	`StudentID` INT(11) NOT NULL DEFAULT '0',
	`CourseID` INT(11) NOT NULL DEFAULT '0',
	PRIMARY KEY (`StudentID`, `CourseID`),
	UNIQUE INDEX `Index 1` (`Serial`)
)
ENGINE=InnoDB
AUTO_INCREMENT= 1
;

/* Populate registry table */

INSERT INTO registry	(StudentID, CourseID) VALUES (1, 1);
INSERT INTO registry	(StudentID, CourseID) VALUES (1, 3);
INSERT INTO registry	(StudentID, CourseID) VALUES (1, 5);
INSERT INTO registry	(StudentID, CourseID) VALUES (2, 1);
INSERT INTO registry	(StudentID, CourseID) VALUES (2, 4);
INSERT INTO registry	(StudentID, CourseID) VALUES (2, 6);
INSERT INTO registry	(StudentID, CourseID) VALUES (3, 2);
INSERT INTO registry	(StudentID, CourseID) VALUES (3, 3);
INSERT INTO registry	(StudentID, CourseID) VALUES (3, 5);
INSERT INTO registry	(StudentID, CourseID) VALUES (4, 2);
INSERT INTO registry	(StudentID, CourseID) VALUES (4, 4);
INSERT INTO registry	(StudentID, CourseID) VALUES (4, 6);
INSERT INTO registry	(StudentID, CourseID) VALUES (5, 1);
INSERT INTO registry	(StudentID, CourseID) VALUES (5, 3);
INSERT INTO registry	(StudentID, CourseID) VALUES (5, 5);
INSERT INTO registry	(StudentID, CourseID) VALUES (6, 2);
INSERT INTO registry	(StudentID, CourseID) VALUES (6, 4);
INSERT INTO registry	(StudentID, CourseID) VALUES (6, 6);
INSERT INTO registry	(StudentID, CourseID) VALUES (7, 1);
INSERT INTO registry	(StudentID, CourseID) VALUES (7, 3);
INSERT INTO registry	(StudentID, CourseID) VALUES (7, 5);
INSERT INTO registry	(StudentID, CourseID) VALUES (8, 2);
INSERT INTO registry	(StudentID, CourseID) VALUES (8, 4);
INSERT INTO registry	(StudentID, CourseID) VALUES (8, 6);
INSERT INTO registry	(StudentID, CourseID) VALUES (9, 1);
INSERT INTO registry	(StudentID, CourseID) VALUES (9, 3);
INSERT INTO registry	(StudentID, CourseID) VALUES (9, 5);
INSERT INTO registry	(StudentID, CourseID) VALUES (10, 2);
INSERT INTO registry	(StudentID, CourseID) VALUES (10, 4);
INSERT INTO registry	(StudentID, CourseID) VALUES (10, 6);

/* End Create registry table */