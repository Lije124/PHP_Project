<?php

class Deletestudent_Model extends Model {

    function __construct() {
        parent::__construct();
    }

    public function deleteStudent() {
        $thisStudentID = Session::get('student');
        $sql = "DELETE FROM students WHERE ID = :thisStudentID";
        $stmt = $this->db->prepare($sql);
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->execute();
        return true;
         }
    }
    
    public function updateRegistry() {
        $thisStudentID = Session::get('student');
        $sql = "DELETE FROM registry WHERE StudentID = :thisStudentID";
        $stmt = $this->db->prepare($sql);
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->execute();
        return true;
         }
    }

} 
             