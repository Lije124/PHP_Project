<?php

class Updatestudent_Model extends Registry_Model {

    function __construct() {
        parent::__construct();
    }
    
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    
    public function updateStudent($thisImage) {
        
        $thisStudentID = Session::get('student');
        if (isset ($thisImage)) { 
            $sql = "UPDATE students SET Name = :Name, Phone = :Phone, Email = :Email, Image = :Image WHERE ID = :thisStudentID";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->bindParam(':Name', $Name);
            $stmt->bindParam(':Phone', $Phone);
            $stmt->bindParam(':Email', $Email);
            $stmt->bindParam(':Image', $Image);
            $Image = $thisImage;
        } else {
            $sql = "UPDATE students SET Name = :Name, Phone = :Phone, Email = :Email WHERE ID = :thisStudentID";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->bindParam(':Name', $Name);
            $stmt->bindParam(':Phone', $Phone);
            $stmt->bindParam(':Email', $Email);
        }
        
        $Name = $_POST['studentname'];
        if(!$Name) {
            echo "You cannot remove the student's name.";
            die();
            }
        $Phone = $_POST['studentphone'];
        if(!$Phone) {
            echo "You cannot remove the student's phone number.";
            die();
            }
        $Email = $_POST['studentemail'];
        if(!$Email) {
            echo "You cannot remove the student's email address.";
            die();
            }
        $mailAddress = $this->test_input($_POST['studentemail']);
        if (!filter_var($mailAddress, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format";
            die();
        }
        
        
        $stmt->execute();
        
        return true;
    }
    
           public function getRegistry ($thisStudentID) {
        
        $sql = "SELECT registry.CourseID, courses.Name FROM registry INNER JOIN courses ON registry.CourseID = courses.ID
            WHERE registry.StudentID = :thisStudentID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->execute();
            $stmt->bindColumn('CourseID', $CourseID);
            $stmt->bindColumn('Name', $CourseName);
            $registryResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $registryResult;
    }
   
} 
             