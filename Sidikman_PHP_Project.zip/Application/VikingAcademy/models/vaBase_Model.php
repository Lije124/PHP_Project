<?php

class vaBase_Model extends Model {
    
    function __construct() {
        $this->db = new Database();
    }
    
    public $thisImage = '';
    
    public function uploadImage($control) {
        
        if($_FILES["uploadimage"]["name"] != '') {
            
            $target_dir = "public/images/" . $control . "/";
            $target_file = $target_dir . basename($_FILES["uploadimage"]["name"]);
            $thisImage = basename($_FILES["uploadimage"]["name"]);
            $uploadOK = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_POST["submit"])) {
                $check = getimagesize($_FILES["uploadimage"]["tmp_name"]);
                if($check !== false) {
                    $uploadOK = 1;
                } else {
                    echo "The file is not an image.<br>";
                    $uploadOK = 0;
                    die();
                }
            }        

            if (file_exists($target_file)) {
                echo "The file already exists.<br>";
                $uploadOK = 0;
                die();
            }
            
            $image_info = getimagesize($_FILES["uploadimage"]["tmp_name"]);
            $image_width = $image_info[0];
            $image_height = $image_info[1];

            if ($image_width != 240 || $image_height != 240) {
                echo "The file must be 240 pixels square.<br>";
                $uploadOK = 0;
                die();
            }
            
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                echo "Only JPEG, JPEG, PNG and GIF files are allowed.<br>";
                $uploadOK = 0;
                die();
            }

            if($uploadOK == 1) {
                if (move_uploaded_file($_FILES["uploadimage"]["tmp_name"], $target_file)) {
                    return $thisImage;
                } else {
                    echo "There was an error uploading your file.";
                    die();
                }
            }
        } else {
            if(Session::get('upload') == 'add') {
                echo "Please upload a photo.";
                die();
            } 
        }
    }
}
