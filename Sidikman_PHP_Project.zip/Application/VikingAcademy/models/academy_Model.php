<?php

class Academy_Model extends Registry_Model {

    function __construct() {
        parent::__construct();
    }
    
}