<?php

class Addcourse_Model extends Registry_Model {

    function __construct() {
    parent::__construct();
    }
      
    public function addCourse($thisImage) {

        $sql = "INSERT INTO courses (Name, Description, Image) VALUES (:Name, :Description, :Image)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':Name', $Name);
        $stmt->bindParam(':Description', $Description);
        $stmt->bindParam(':Image', $Image);

        $Name = $_POST['coursename'];
        if(!$Name) {
            echo "Please enter the course title.";
            die();
        }
        $Description = $_POST['coursedesc'];
        if(!$Description) {
            echo "Please enter the course description.";
            die();
        }
        $Image = $thisImage;
        
        $stmt->execute();
        
        return true;
    }
    
    public $thisCourseResult = '';
    
    public function getNewCourse() {
        
        $Name = '';
        $courseID = '';
        
            $sql = "SELECT ID FROM courses WHERE Name = :Name";
            if ($stmt = $this->db->prepare($sql)) {
                $stmt->bindParam(':Name', $Name);
                $Name = $_POST['coursename'];
                $stmt->execute();
                $stmt->bindColumn('ID', $courseID);
                $thisCourseID = $stmt->fetch();
            } 
            $thisCourseResult = $thisCourseID['ID'];
            return $thisCourseResult;
    }
    
    public function getRegistry ($thisCourseResult) {
        
        $studentID = '';
        $thisCourse = '';
        
        $sql = "SELECT StudentID FROM registry WHERE CourseID = :thisCourseID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisCourseID', $thisCourse);
            $thisCourse = $thisCourseResult;
            $stmt->execute();
            $stmt->bindColumn('StudentID', $studentID);
            $registryResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $registryResult;
    }
    
    
      
}

