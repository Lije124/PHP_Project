<?php

class Addadmin_Model extends Administration_Model {

    function __construct() {
        parent::__construct();
    }
    
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    
    
    public function addAdmin($thisImage) {

        $sql = "INSERT INTO admins (Name, Role, Phone, Email, Image) VALUES (:Name, :Role, :Phone, :Email, :Image)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':Name', $Name);
        $stmt->bindParam(':Role', $Role);
        $stmt->bindParam(':Phone', $Phone);
        $stmt->bindParam(':Email', $Email);
        $stmt->bindParam(':Image', $Image);

        $Name = $_POST['adminname'];
        if(!$Name) {
            echo "Please enter the manager's name.";
            die();
        }
        $Role = $_POST['adminrole'];
        if(!$Role) {
            echo "Please enter the manager's administrative role.";
            die();
        }
        $Phone = $_POST['adminphone'];
        if(!$Phone) {
            echo "Please enter the manager's phone number.";
            die();
        }
        $Email = $_POST['adminemail'];
        if(!$Email) {
            echo "Please enter the manager's email address.";
            die();
        }
        $mailAddress = $this->test_input($_POST['adminemail']);
        if (!filter_var($mailAddress, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format";
            die();
        }
        
        $Image = $thisImage;
            
        $stmt->execute();
        
        return true;
    }

public $thisAdminResult = '';
    
    public function getNewAdmin() {
        
        $Name = '';
        $thisAdminID = '';
        $adminID = '';
        
        $sql = "SELECT ID FROM admins WHERE Name = :Name";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':Name', $Name);
            $Name = $_POST['adminname'];
            $stmt->execute();
            $stmt->bindColumn('ID', $adminID);
            $thisAdminID = $stmt->fetch();
        } 
            
        $thisAdminResult = $thisAdminID['ID'];
        return $thisAdminResult;
    }
}