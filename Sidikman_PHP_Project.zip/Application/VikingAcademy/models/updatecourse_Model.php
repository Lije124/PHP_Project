<?php

class Updatecourse_Model extends Registry_Model {

    function __construct() {
        parent::__construct();
    }

    public function updateCourse($thisImage) {
        
        $thisCourseID = Session::get('course');
        if (isset ($thisImage)) { 
            $sql = "UPDATE courses SET Name = :Name, Description = :Description, Image = :Image WHERE ID = :thisCourseID";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':thisCourseID', $thisCourseID);
            $stmt->bindParam(':Name', $Name);
            $stmt->bindParam(':Description', $Description);
            $stmt->bindParam(':Image', $Image);
            $Image = $thisImage;
            } else {
                $sql = "UPDATE courses SET Name = :Name, Description = :Description WHERE ID = :thisCourseID";
                $stmt = $this->db->prepare($sql);
                $stmt->bindParam(':thisCourseID', $thisCourseID);
                $stmt->bindParam(':Name', $Name);
                $stmt->bindParam(':Description', $Description);
                }

        $Name = $_POST['coursename'];
        if(!$Name) {
            echo "You cannot remove the course title.";
            die();
            }
        $Description = $_POST['coursedesc'];
        if(!$Description) {
            echo "You cannot remove the course description.";
            die();
            }
        
        $stmt->execute();
        
        return true;
    }
    
    public function getRegistry ($thisCourseResult) {
        
        $studentID = '';
        $thisCourse = '';
        
        $sql = "SELECT StudentID FROM registry WHERE CourseID = :thisCourseID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisCourseID', $thisCourse);
            $thisCourse = $thisCourseResult;
            $stmt->execute();
            $stmt->bindColumn('StudentID', $studentID);
            $registryResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $registryResult;
    }
    
    
      
}

