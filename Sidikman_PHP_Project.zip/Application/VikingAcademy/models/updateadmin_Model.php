<?php

class Updateadmin_Model extends Administration_Model {

    function __construct() {
        parent::__construct();
    }
    
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    
    public function updateAdmin($thisImage) {
        $thisAdminID = Session::get('admin');
        if (isset ($thisImage)) { 
            $sql = "UPDATE admins SET Name = :Name, Role = :Role, Phone = :Phone, Email = :Email, Image = :Image WHERE ID = :thisAdminID";
            if ($stmt = $this->db->prepare($sql)) {
                $stmt->bindParam(':thisAdminID', $thisAdminID);
                $stmt->bindParam(':Name', $Name);
                $stmt->bindParam(':Role', $Role);
                $stmt->bindParam(':Phone', $Phone);
                $stmt->bindParam(':Email', $Email);
                $stmt->bindParam(':Image', $Image);
                $Image = $thisImage;
        }} else {
                $sql = "UPDATE admins SET Name = :Name, Role = :Role, Phone = :Phone, Email = :Email WHERE ID = :thisAdminID";
                if ($stmt = $this->db->prepare($sql)) {
                    $stmt->bindParam(':thisAdminID', $thisAdminID);
                    $stmt->bindParam(':Name', $Name);
                    $stmt->bindParam(':Role', $Role);
                    $stmt->bindParam(':Phone', $Phone);
                    $stmt->bindParam(':Email', $Email);
        }}

            $Name = $_POST['adminname'];
            if(!$Name) {
            echo "You cannot remove the manager's name.";
            die();
            }
            $Role = $_POST['adminrole'];
            if(!$Role) {
            echo "O Great Odin, the Norns have decreed that each manager shall have a role.";
            die();
            }
            $Phone = $_POST['adminphone'];
            if(!$Phone) {
            echo "You cannot remove the manager's phone number.";
            die();
            }
            $Email = $_POST['adminemail'];
            if(!$Email) {
                echo "You cannot remove the manager's email address.";
                die();
            }
            $mailAddress = $this->test_input($_POST['adminemail']);
            if (!filter_var($mailAddress, FILTER_VALIDATE_EMAIL)) {
                echo "Invalid email format";
                die();
            }
        
            $stmt->execute();
            
            return true;
}
}