<?php

class Deletecourse_Model extends Model {

    function __construct() {
        parent::__construct();
    }
    
    public function deleteCourse() {
        $thisCourseID = Session::get('course');
        $sql = "DELETE FROM courses WHERE ID = :thisCourseID";
        $stmt = $this->db->prepare($sql);
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisCourseID', $thisCourseID);
            $stmt->execute();
        return true;
         }
    }
    
        public function updateRegistry() {
        $thisStudentID = Session::get('course');
        $sql = "DELETE FROM registry WHERE CourseID = :thisCourseID";
        $stmt = $this->db->prepare($sql);
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisCourseID', $thisCourseID);
            $stmt->execute();
        return true;
         }
    }

} 
             