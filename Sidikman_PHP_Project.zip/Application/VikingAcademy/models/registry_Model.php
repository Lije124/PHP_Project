<?php

class Registry_Model extends vaBase_Model {

public $courseResult = [];
    
    public function getCourses () {
        
        $sql = "SELECT * FROM courses";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->execute();
            $stmt->bindColumn('ID', $courseID);
            $stmt->bindColumn('Name', $courseName);
            $stmt->bindColumn('Description', $courseDesc);
            $stmt->bindColumn('Image', $courseImage);
            $courseResult = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } 
        return $courseResult;
    }
    
    public $studentResult = [];
    
    public function getStudents () {
        
        $sql = "SELECT * FROM students";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->execute();
            $stmt->bindColumn('ID', $studentID);
            $stmt->bindColumn('Name', $studentName);
            $stmt->bindColumn('Phone', $studentPhone);
            $stmt->bindColumn('Email', $studentEmail);
            $stmt->bindColumn('Image', $studentImage);
            $studentResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $studentResult;
    }
    
    public $thisStudentResult = [];
    
    public function getThisStudent ($thisStudentID) {
        
        $sql = "SELECT ID, Name, Phone, Email, Image from students WHERE ID = :thisStudentID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->execute();
            $stmt->bindColumn('ID', $studentID);
            $stmt->bindColumn('Name', $studentName);
            $stmt->bindColumn('Phone', $studentPhone);
            $stmt->bindColumn('Email', $studentEmail);
            $stmt->bindColumn('Image', $studentImage);
            $thisStudentResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $thisStudentResult;
        
    }
    
    public $thisCourseResult = [];
    
    public function getThisCourse ($thisCourseID) {
        
        $sql = "SELECT ID, Name, Description, Image from courses WHERE ID = :thisCourseID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisCourseID', $thisCourseID);
            $stmt->execute();
            $stmt->bindColumn('ID', $courseID);
            $stmt->bindColumn('Name', $courseName);
            $stmt->bindColumn('Description', $courseDesc);
            $stmt->bindColumn('Image', $courseImage);
            $thisCourseResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $thisCourseResult;

    }
    
    public function updateRegistry ($newStudentID) {
            if($_POST['course']) {
                foreach ($_POST['course'] as $checked) { 

                    $sql = "INSERT INTO registry (StudentID, CourseID) VALUES (:StudentID, :CourseID)";
                        if ($stmt = $this->db->prepare($sql)) {
                            $stmt->bindParam(':StudentID', $StudentID);
                            $stmt->bindParam(':CourseID', $CourseID);
                            $StudentID = $newStudentID;
                            $CourseID = $checked;
                            $stmt->execute();
                        }
                }

                return true;
            }
    }
    
}