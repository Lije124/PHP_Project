<?php

class Student_Model extends Registry_Model {

    function __construct() {
        parent::__construct();
    }
    
    
    public function getRegistry ($thisStudentID) {
        
        $sql = "SELECT registry.CourseID, courses.Name, courses.Image FROM registry INNER JOIN courses ON registry.CourseID = courses.ID
WHERE registry.StudentID = :thisStudentID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->execute();
            $stmt->bindColumn('CourseID', $CourseID);
            $stmt->bindColumn('Name', $CourseName);
            $stmt->bindColumn('Image', $CourseImage);
            $registryResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $registryResult;
        var_dump($registryResult);
        die();
    }
    
  

}