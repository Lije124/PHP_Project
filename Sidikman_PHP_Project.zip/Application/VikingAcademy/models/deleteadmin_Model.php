<?php

class Deleteadmin_Model extends Model {

    function __construct() {
        parent::__construct();
    }
    
    public function deleteAdmin() {
        $thisAdminID = Session::get('admin');
        $sql = "DELETE FROM admins WHERE ID = :thisAdminID";
        $stmt = $this->db->prepare($sql);
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisAdminID', $thisAdminID);
            $stmt->execute();
        return true;
         }
    }
    
} 
             