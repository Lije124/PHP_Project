<?php

class Manager_Model extends Administration_Model {

    function __construct() {
        parent::__construct();
    }
    
}

