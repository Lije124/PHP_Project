<?php

class Login_Model extends Model {

    function __construct() {
        parent::__construct();
    }
    
    public $login = '';
    public $password = '';
    
    public function authenticate () {
      
        $retValue = false;
        $login = $_POST['login'];
        $password = $_POST['password'];
        
        if (!$login) {
            echo "Please enter your username.";
            die();
        }
        elseif (!$password) {
            echo "Please enter your password.";
            die();
        }
        else {
     
        $password = sha1(config::$salt_prefix . $_POST['password'] . config::$salt_suffix);
        $role = "";
        $image = "";
        
        $sql = "SELECT Name, Role, Image FROM admins WHERE Email = :Email AND Password = :Password";
                if ($stmt = $this->db->prepare($sql)) {
                    $stmt->bindParam(':Email', $login);
                    $stmt->bindParam(':Password', $password);
                    $stmt->execute();
                    $stmt->bindColumn('Name', $name);
                    $stmt->bindColumn('Role', $role);
                    $stmt->bindColumn('Image', $image);
                    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if($result) {
                        if (isset($role)) {
                            Session::set('name', $name);
                            Session::set('role', $role);
                            Session::set('image', $image);
                            Session::set('loggedIn' , true);
                            $retValue = true;
                        } 
                    } else {
                            echo "Unauthorized login. Please try again.";
                            die();
                    } 
                }
  
                return $retValue;
        }      
        }
    }