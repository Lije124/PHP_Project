<?php

class Course_Model extends Registry_Model {

    function __construct() {
        parent::__construct();
    }
    
    public function getRegistry ($thisCourseID) {
        
        $studentID = '';
        $studentName = '';
        $studentImage = '';
                
        $sql = "SELECT registry.StudentID, students.Name, students.Image FROM registry INNER JOIN students ON registry.StudentID = students.ID
WHERE registry.CourseID = :thisCourseID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisCourseID', $thisCourseID);
            $stmt->execute();
            $stmt->bindColumn('StudentID', $studentID);
            $stmt->bindColumn('Name', $studentName);
            $stmt->bindColumn('Image', $studentImage);
            $registryResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $registryResult;
    }
    
    
      
}

