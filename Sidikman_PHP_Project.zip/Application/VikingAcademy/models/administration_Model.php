<?php

class Administration_Model extends vaBase_Model {

public $adminResult = [];
    
        public function getAdmins () {
            
        $sql = "SELECT * FROM admins";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->execute();
            $stmt->bindColumn('Name', $adminName);
            $stmt->bindColumn('Role', $adminRole);
            $stmt->bindColumn('Phone', $adminPhone);
            $stmt->bindColumn('Email', $adminEmail);
            $stmt->bindColumn('Image', $adminImage);
            $adminResult = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } 
        return $adminResult;
    } 
    
    public $thisAdminResult = [];
    
    public function getThisAdmin ($thisAdminID) {
        
        $sql = "SELECT ID, Name, Role, Phone, Email, Image from admins WHERE ID = :thisAdminID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisAdminID', $thisAdminID);
            $stmt->execute();
            $stmt->bindColumn('ID', $adminID);
            $stmt->bindColumn('Name', $adminName);
            $stmt->bindColumn('Role', $adminRole);
            $stmt->bindColumn('Phone', $adminPhone);
            $stmt->bindColumn('Email', $adminEmail);
            $stmt->bindColumn('Image', $adminImage);
            $thisAdminResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $thisAdminResult;

    }
    
}