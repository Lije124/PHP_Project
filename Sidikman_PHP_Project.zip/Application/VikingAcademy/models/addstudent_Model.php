<?php

class Addstudent_Model extends Registry_Model {

    function __construct() {
        parent::__construct();
    }
    
   function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    
    public function addStudent($thisImage) {
        
        $sql = "INSERT INTO students (Name, Phone, Email, Image) VALUES (:Name, :Phone, :Email, :Image)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':Name', $Name);
        $stmt->bindParam(':Phone', $Phone);
        $stmt->bindParam(':Email', $Email);
        $stmt->bindParam(':Image', $Image);

        $Name = $_POST['studentname'];
        if(!$Name) {
            echo "Please enter the student's name.";
            die();
        }
        $Phone = $_POST['studentphone'];
        if(!$Phone) {
            echo "Please enter the student's phone number.";
            die();
        }
        $Email = $_POST['studentemail'];
        if(!$Email) {
            echo "Please enter the student's email address.";
            die();
        }
        
        $mailAddress = $this->test_input($_POST['studentemail']);
        if (!filter_var($mailAddress, FILTER_VALIDATE_EMAIL)) {
            echo "Invalid email format";
            die();
        }
        
        $Image = $thisImage;
           
        $stmt->execute();
        
        return true;
    }
    
    public $thisStudentResult = '';
    
    public function getNewStudent() {
        
        $Name = '';
        $thisStudentID = '';
        $studentID = '';
        
            $sql = "SELECT ID FROM students WHERE Name = :Name";
            if ($stmt = $this->db->prepare($sql)) {
                $stmt->bindParam(':Name', $Name);
                $Name = $_POST['studentname'];
                $stmt->execute();
                $stmt->bindColumn('ID', $studentID);
                $thisStudentID = $stmt->fetch();
            } 
            $thisStudentResult = $thisStudentID['ID'];
            return $thisStudentResult;
            
            
    }
    
        
    
    public function getRegistry ($thisStudentID) {
        
        $sql = "SELECT registry.CourseID, courses.Name FROM registry INNER JOIN courses ON registry.CourseID = courses.ID
            WHERE registry.StudentID = :thisStudentID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisStudentID', $thisStudentID);
            $stmt->execute();
            $stmt->bindColumn('CourseID', $CourseID);
            $stmt->bindColumn('Name', $CourseName);
            $registryResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        return $registryResult;
    }
   
} 
             