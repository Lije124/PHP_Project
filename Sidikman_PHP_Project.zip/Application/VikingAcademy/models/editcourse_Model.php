<?php

class Editcourse_Model extends Registry_Model {

        function __construct() {
        parent::__construct();
    }
    
   public function getRegistry () {
        
        $thisCourseID = Session::get('course');
                        
        $sql = "SELECT StudentID FROM registry WHERE CourseID = :thisCourseID";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bindParam(':thisCourseID', $thisCourseID);
            $stmt->execute();
            $stmt->bindColumn('StudentID', $studentID);
            $registryResult = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 

        return $registryResult;
    }
    
    
      
}

