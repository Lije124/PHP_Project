<?php

class Config {
    
    const URL = "http://localhost:8080/VikingAcademy/";
    
    public static $server;
    public static $database;
    public static $user;
    public static $password;
    
    public static $salt_prefix;
    public static $salt_suffix;

}

?>
