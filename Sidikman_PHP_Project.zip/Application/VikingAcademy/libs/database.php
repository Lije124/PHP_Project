<?php

class Database extends PDO {

    function __construct() {
        parent::__construct('mysql:dbname=vikingacademy;host=localhost', Config::$user, Config::$password);
    }
}
   
?>