document.getElementById('upload').addEventListener('change', function() {
	var file;
	var destination = document.getElementById('thumbnail');
	destination.innerHTML = '';
                
        for(var x = 0, xlen = this.files.length; x < xlen; x++) {
		file = this.files[x];
		if(file.type.indexOf('image') != -1) {

                    var reader = new FileReader();

                    reader.onload = function(e) {
                        var img = new Image();
                        img.src = e.target.result;
                        destination.appendChild(img);
                    };
			
                reader.readAsDataURL(file);
        }
    }
    	
        });