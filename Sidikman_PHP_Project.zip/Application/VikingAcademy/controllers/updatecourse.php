<?php

class Updatecourse extends Registry {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function updateCourse() {
        
        $control = "courses";
        Session::set('upload', 'update');
        $thisCourseID = Session::get('course');
        $this->_view->courseImage = $this->_model->uploadImage($control);
        $thisImage = $this->_view->courseImage;
        $this->_view->updateCourse = $this->_model->updateCourse($thisImage);
 //       $this->_view->courseResult = $this->_model->getCourses ();
 //       $this->_view->updateRegistry = $this->_model->updateRegistry($thisCourseID);
        Session::set('status', 'courseupdated');
        header("location: " . config::URL . "Course/index/$thisCourseID");        
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}
