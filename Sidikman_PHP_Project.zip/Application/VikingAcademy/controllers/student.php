<?php

class Student extends Registry {
    
    public $thisStudentID = '';
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function index() {
        $thisStudentID = $this->a;
        $this->_view->courseData = $this->_model->getCourses();
        $this->_view->studentData = $this->_model->getStudents();
        $this->_view->thisStudent = $this->_model->getThisStudent($thisStudentID);
        $this->_view->registryData = $this->_model->getRegistry($thisStudentID);
        $this->_view->render('student/index');
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}