<?php

class Updateadmin extends Administration {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function updateAdmin() {
        
        $control = "admins";
        Session::set('upload', 'update');
        $thisAdminID = Session::get('admin');
        $this->_view->adminImage = $this->_model->uploadImage($control);
            $thisImage = $this->_view->adminImage;
        $this->_view->updateAdmin = $this->_model->updateAdmin($thisImage);
        Session::set('status', 'adminupdated');
		header("location: " . config::URL . "Manager/index/$thisAdminID");
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}

