<?php

class Addstudent extends Registry {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function index() {
        $this->_view->courseData = $this->_model->getCourses();
        $this->_view->studentData = $this->_model->getStudents();
        $this->_view->render('addstudent/index');
    }
    
    public function addStudent() {
        
        $control = "students";
        Session::set('upload', 'add');
        $this->_view->courseData = $this->_model->getCourses();
        $this->_view->studentImage = $this->_model->uploadImage($control);
            $thisImage = $this->_view->studentImage;
        $this->_view->newStudent = $this->_model->addStudent($thisImage);
        
        $this->_view->newStudentID = $this->_model->getNewStudent();
            $NewStudentID = $this->_view->newStudentID;
        $this->_view->registryUpdate = $this->_model->updateRegistry($NewStudentID);
        $this->_view->registryData = $this->_model->getRegistry($NewStudentID);
        Session::set('status', 'studentadded');
		header("location: " . config::URL . "Student/index/$NewStudentID");
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}