<?php

class Updatestudent extends Registry {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
                
    public function updateStudent() {
        
        $control = "students";
        Session::set('upload', 'update');
        $thisStudentID = Session::get('student');
        $this->_view->studentImage = $this->_model->uploadImage($control);
            $thisImage = $this->_view->studentImage;
        $this->_view->updateStudent = $this->_model->updateStudent($thisImage);
        $this->_view->courseResult = $this->_model->getCourses ();
        $this->_view->registryUpdate = $this->_model->updateRegistry($thisStudentID);
        $this->_view->registryData = $this->_model->getRegistry($thisStudentID);
        Session::set('status', 'studentupdated');
        header("location: " . config::URL . "Student/index/$thisStudentID");  
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}