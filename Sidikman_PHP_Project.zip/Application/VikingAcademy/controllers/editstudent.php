<?php

class Editstudent extends Registry {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public $thisStudentID = '';
    
    public function index() {
        if (Session::get('student')) {
            Session::remove('student');
        }
        $thisStudentID = $this->a;
        Session::set('student', $thisStudentID);
        $this->_view->courseData = $this->_model->getCourses();
        $this->_view->studentData = $this->_model->getStudents();
        $this->_view->thisStudent = $this->_model->getThisStudent($thisStudentID);
        $this->_view->registryData = $this->_model->getRegistry($thisStudentID);
        $this->_view->render('editstudent/index');
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}