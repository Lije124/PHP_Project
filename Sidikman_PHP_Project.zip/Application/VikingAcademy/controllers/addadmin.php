<?php

class Addadmin extends Administration {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function index() {
        $this->_view->adminData = $this->_model->getAdmins();
        $this->_view->render('addadmin/index');
    }
    
    public function addAdmin() {
        
        $NewAdminID = '';
        $control = "admins";
        Session::set('upload', 'add');
        $this->_view->adminImage = $this->_model->uploadImage($control);
            $thisImage = $this->_view->adminImage;
        $this->_view->newAdmin = $this->_model->addAdmin($thisImage);
        $this->_view->newAdminID = $this->_model->getNewAdmin();
        $NewAdminID = $this->_view->newAdminID;
        Session::set('status', 'adminadded');
        header("location: " . config::URL . "Manager/index/$NewAdminID");
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}

