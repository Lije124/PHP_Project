<?php

class login extends Controller {

    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }

    public function login() {
        if (SESSION::get('loggedIn')) {
            SESSION::remove('loggedIn');
        }
        $this->_view->render('login/index');
    }
    
    public function authenticate() {
        if ($this->_model->authenticate() == true) {
            header('location:' . config::URL . 'academy/index');
            } else {
              $this->logout();
              }
    }
   
    public function logout() {
        SESSION::remove('loggedIn');
        SESSION::remove('role');
        header('location:' . config::URL);
    }
}
