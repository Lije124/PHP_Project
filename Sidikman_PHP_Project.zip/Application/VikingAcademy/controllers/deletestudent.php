<?php

class deletestudent extends Controller {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function deleteStudent() {
        $this->_view->deleteStudent = $this->_model->deleteStudent();
        $this->_view->updateRegistry = $this->_model->updateRegistry();
        Session::set('status', 'studentdeleted');
		header("location: " . config::URL . "Academy/index");
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}