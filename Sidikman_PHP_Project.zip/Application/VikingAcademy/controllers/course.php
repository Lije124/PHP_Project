<?php

class Course extends Registry {
    
    public $courseData = [];
    public $thisCourse = [];
    public $thisCOurseID = '';
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function index() {
        $thisCourseID = $this->a;
        $this->_view->courseData = $this->_model->getCourses();
        $this->_view->studentData = $this->_model->getStudents();
        $this->_view->thisCourse = $this->_model->getThisCourse($thisCourseID);
        $this->_view->registryData = $this->_model->getRegistry($thisCourseID);
        $this->_view->render('course/index');
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}
