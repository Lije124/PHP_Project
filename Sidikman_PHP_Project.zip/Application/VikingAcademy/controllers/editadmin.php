<?php

class Editadmin extends Administration {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public $thisAdminID = '';
    
    public function index() {
        if (Session::get('admin')) {
            Session::remove('admin');
        }
        $thisAdminID = $this->a;
        Session::set('admin', $thisAdminID);
        $this->_view->adminData = $this->_model->getAdmins();
        $this->_view->thisAdmin = $this->_model->getThisAdmin($thisAdminID);
        $this->_view->render('editadmin/index');
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}

