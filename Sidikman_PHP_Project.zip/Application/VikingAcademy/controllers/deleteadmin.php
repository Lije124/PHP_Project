<?php

class deleteadmin extends Controller {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function deleteAdmin() {
        $this->_view->deleteAdmin = $this->_model->deleteAdmin();
        Session::set('status', 'admindeleted');
		header("location: " . config::URL . "Admin/index");
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}