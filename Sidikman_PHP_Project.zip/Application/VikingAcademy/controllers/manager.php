<?php

class Manager extends Administration {
    
    public $adminData = [];
    public $thisAdmin = [];
    public $thisAdminID = '';
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function index() {
        $thisAdminID = $this->a;
        $this->_view->thisAdminID = $thisAdminID;
        $this->_view->adminData = $this->_model->getAdmins();
        $this->_view->thisAdmin = $this->_model->getThisAdmin($thisAdminID);
        $this->_view->render('manager/index');
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}
