<?php

class Administration extends Controller {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}

