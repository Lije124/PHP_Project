<?php

class Addcourse extends Registry {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public function index() {
        $this->_view->courseData = $this->_model->getCourses();
        $this->_view->studentData = $this->_model->getStudents();
        $this->_view->render('addcourse/index');
    }
    
    public function addCourse() {
        
        $NewCourseID = '';
        $control = "courses";
        Session::set('upload', 'add');
        $this->_view->courseImage = $this->_model->uploadImage($control);
            $thisImage = $this->_view->courseImage;
        $this->_view->newCourse = $this->_model->addCourse($thisImage);
        $this->_view->newCourseID = $this->_model->getNewCourse();
            $NewCourseID = $this->_view->newCourseID;
//        $this->_view->registryData = $this->_model->getRegistry($NewCourseID);
        Session::set('status', 'courseadded');
		header("location: " . config::URL . "Course/index/$NewCourseID");
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}
