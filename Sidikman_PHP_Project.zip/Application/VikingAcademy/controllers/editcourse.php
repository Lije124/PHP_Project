<?php

class Editcourse extends Registry {
    
    function __construct() {
        parent::__construct();
        $this->loadModel(__CLASS__);
    }
    
    public $thisCourseID = '';
    
    public function index() {
        if (Session::get('course')) {
            Session::remove('course');
        }
        $thisCourseID = $this->a;
        Session::set('course', $thisCourseID);
        $this->_view->courseData = $this->_model->getCourses();
        $this->_view->studentData = $this->_model->getStudents();
        $this->_view->thisCourse = $this->_model->getThisCourse($thisCourseID);
        $this->_view->registryData = $this->_model->getRegistry();
        $this->_view->render('editcourse/index');
    }
    
    private function _error($msg){ 
        require_once 'controllers/error.php';
        $err = new appError($msg);
        $err->calcError($msg);
        return false;
    }
}
