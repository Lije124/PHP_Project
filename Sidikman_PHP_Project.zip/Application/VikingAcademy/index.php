<?php

spl_autoload_register(function($class) {
    if (file_exists("libs/$class.php")) {
        require_once "libs/$class.php";
    } else if (file_exists("controllers/$class.php")) {
        require_once "controllers/$class.php";
    } else if (file_exists("models/$class.php")) {
        require_once "models/$class.php";
    } else {
        echo "$class not found.";
        exit();
    }
});

Session::init();
setConfig();
$app = new Bootstrap();
$app->init();

function setConfig() {
    Config::$server = 'localhost';
    Config::$database = 'vikingacademy';
    Config::$user = 'root';
    Config::$password = '';
    Config::$salt_prefix = 'fenrir';
    Config::$salt_suffix= 'jormungandr';
}