<div id="content" class="content">
    <table>
        <tr>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Courses
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addcourse/index/"  method="post"> 
                                <button type="submit" id="add_course" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" height="5"></td>
                    </tr>
                    <tr>
                         <td colspan="2" class="redline"></td>
                    </tr>
                    <tr>
                         <td colspan="2" height="10"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            
                            <table>
                                 
                               <?php foreach($this->courseData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Course/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/courses/<?php echo $row['Image'] ?>" alt="CourseImage"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Course/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            <td class="redvert"></td>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Students
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addstudent/index/"  method="post"> 
                                <button type="submit" id="add_student" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td height="5" colspan="2"></td>
                    </tr>
                    <tr>
                        <td class="redline" colspan="2"></td>
                    </tr>
                    <tr>
                        <td height="10" colspan="2"</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            <table>

                               <?php foreach($this->studentData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Student/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/students/<?php echo $row['Image'] ?>" alt="StudentImage"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Student/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            <td class="redvert"></td>
            <td class="main_home" valign="middle">
                <div class="courseeditbox">
                     <table>
                         <form action="<?php echo config::URL ?>updatecourse/updateCourse"  method="post" enctype="multipart/form-data"> 
                            <tr>
                                <td colspan="3">
                                     <p class="itemtitle1">Edit Course Details</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" class="line"></td>
                            </tr>
                            <tr>
                                <td colspan="3" height="20"></td>
                            </tr>
                            
                            <?php foreach($this->thisCourse as $row){ ?>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Title&nbsp;&nbsp;&nbsp;</label></td>
                                <td><input class="viking" type="text" name="coursename" align="left" value="<?php echo $row['Name'] ?>"></td>
                                <td class="imagecell" rowspan="4" valign="top"><label class="itemlabel">Image</label><br>
                                    <span id="thumbnail">
                                    <img src="<?php echo config::URL ?>public/images/courses/<?php echo $row['Image'] ?>" alt="Replace the image">
                                    </span><br><br>
                                    <label class="upload" for="upload">Select File</label><input type="file" name="uploadimage" id="upload"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Description&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="textcell"><textarea class="viking" rows="4" cols="21" name="coursedesc"><?php echo $row['Description'] ?></textarea></td>
                            </tr>
                            <tr>
                                <td class="labelcell"></td>
                                <td class="textcell"></td>
                            </tr>
<tr>
                                <td class="labelcell"></td>
                                <td class="textcell"></td>
                            </tr>
                            <tr>
                                <td class="enrolled" colspan="3" valign="top">
                                    <span class="red"><?php echo count($this->registryData) ?></span> students are enrolled in this course.</td>
                            </tr>
                            <?php } ?>
                            <tr>
                                 <td colspan="3">
                                     
                                     <table>
                                         <tr>
                                            <?php if ($_SESSION["role"] != 'Sales'): ?>
                                            <tr>
                                             <td class="editTitle" valign="middle">
                                                <input type="submit" name="submit" value="Update">
                                            </td>
                                            <td class="editButton" valign="middle">
                                                <a class="deleteButton" onclick="return confirm_alert(this);" href=<?php echo config::URL  ?>deletecourse/deleteCourse>Delete</a>
                                            </td>
                                         </tr>
                                             <?php else: ?>
                                                <td class="editCourseCenter" valign="top"> 
                                                    <input type="submit" name="submit" value="Update">
                                                </td>
                                             <?php endif ?>
                                          </tr>
                                     </table>
								</td>
                            </tr>
                         </table>
                </div>
             </td>
        </tr>
    </table>
    
    <script>
        function confirm_alert(node) {
        return confirm("Are you sure you want to delete this student from the registry?");
        }
    </script>