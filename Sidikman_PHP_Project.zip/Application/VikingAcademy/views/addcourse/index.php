<div id="content" class="content">
    <table>
        <tr>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Courses
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addcourse/index/"  method="post"> 
                                <button type="submit" id="add_course" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" height="5"></td>
                    </tr>
                    <tr>
                         <td colspan="2" class="redline"></td>
                    </tr>
                    <tr>
                         <td colspan="2" height="10"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            
                            <table>
                                 
                               <?php foreach($this->courseData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Course/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/courses/<?php echo $row['Image'] ?>" alt="CourseImage"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Course/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            <td class="redvert"></td>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Students
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addstudent/index/"  method="post"> 
                                <button type="submit" id="add_student" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td height="5" colspan="2"></td>
                    </tr>
                    <tr>
                        <td class="redline" colspan="2"></td>
                    </tr>
                    <tr>
                        <td height="10" colspan="2"</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            <table>
                                <?php foreach($this->studentData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Student/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/students/<?php echo $row['Image'] ?>" alt="StudentImage"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Student/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            <td class="redvert"></td>
            <td class="main_home" valign="middle">
                <div class="courseaddbox">
                    <table>
                            <tr>
                                <td colspan="3">
                                     <p class="itemtitle1">Add a Course</p>
                                </td>
                            </tr>
                            <tr>
                                <td class="line" colspan="3"></td>
                            </tr>
                            <tr>
                                <td height="20" colspan="3"></td>
                            </tr>
                            <form action="<?php echo config::URL  ?>Addcourse/addCourse"  method="post" enctype="multipart/form-data"> 
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Title&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="inputcell"><input class="viking" type="text" name="coursename"></td>
                                <td class="imagecell" rowspan="3" valign="top"><label class="itemlabel">Image</label><br>
                                <div id="thumbnail">
                                    <img src="<?php echo config::URL ?>public/images/img_holder.jpg" alt="Add an image">
                                </div>
                                <label class="upload" for="upload">Select File</label><input type="file" name="uploadimage" id="upload"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Description&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="textcell"><textarea class="viking" rows="4" cols="21" name="coursedesc"></textarea></td>
                            </tr>
                            <tr>
                                <td class="labelcell"></td>
                                <td class="textcell"></td>
                            </tr>
                            <tr>
                                <td class="addCourseButton" colspan="3" valign="middle"><input type="submit" name="submit" value="Add"></td>
                            </tr>
                            </form>
                         </table>
                    </div>
             </td>
        </tr>
    </table>