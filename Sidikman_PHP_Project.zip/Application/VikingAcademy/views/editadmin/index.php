<div id="content" class="content">
    <table>
        <tr>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Admins
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addadmin/index/"  method="post"> 
                                <button type="submit" id="add_admin" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" height="5"></td>
                    </tr>
                    <tr>
                         <td colspan="2" class="redline"></td>
                    </tr>
                    <tr>
                         <td colspan="2" height="10"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            
                            <table>
                                 
                               <?php foreach($this->adminData as $row){ ?>    
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/admins/<?php echo $row['Image'] ?>" alt="Administrator Image"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr> 
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            
            <td class="redvert"></td>
            <td class="admin_home" valign="middle">
                <div class="admineditbox">
                        <table>
                            <tr>
                                <td colspan="3">
                                     <p class="itemtitle1">Edit Administrator Details</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" class="line"></td>
                            </tr>
                            <tr>
                                <td colspan="3" height="20"></td>
                            </tr>
                            <form class="formbox" action="<?php echo config::URL ?>updateadmin/updateAdmin"  method="post" enctype="multipart/form-data"> 
                            <?php foreach($this->thisAdmin as $row){ ?>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Name&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="labelcell"><input class="viking" type="text" name="adminname" value="<?php echo $row['Name'] ?>"></td>
                                <td class="imagecell" rowspan="5" valign="top"><label class="itemlabel">Image</label><br>
                                <span id="thumbnail" class="thumbnail">
                                    <img class="img_t" src="<?php echo config::URL ?>public/images/admins/<?php echo $row['Image'] ?>" alt="Add an image">
                                </span><br>
                                <label class="upload" for="upload">Select File</label><input type="file" name="uploadimage" id="upload"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Role&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="labelcell">
                                    <?php if (SESSION::get('role') == 'Owner'): ?>
                                        <select class="viking selectrole" type="text" name="adminrole" value="<?php echo $row['Role'] ?>">
                                            <option value="">Select...</option>
                                            <option value="Manager">Manager</option>
                                            <option value="Sales">Sales</option>
                                        </select>

                                    <?php else: ?>
                                    <input class="viking readonly" type="text" name="adminrole" readonly="readonly" value="<?php echo $row['Role'] ?>"></td>
                                    <?php endif ?>
                                
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Phone&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="labelcell"><input class="viking" type="text" name="adminphone" value="<?php echo $row['Phone'] ?>"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Email&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="labelcell"><input class="viking" type="text" name="adminemail" value="<?php echo $row['Email'] ?>"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"></td>
                                <td class="labelcell"></td>
                            </tr>
                            <?php } ?>
                            <tr>
                                 <td colspan="3">
                                     <table>
                                         <tr>
                                            <?php if ($_SESSION["role"] == 'Owner'): ?>
                                            <tr>
                                             <td class="editTitle" valign="middle">
                                                <input type="submit" name="submit" value="Update">
                                            </td>
                                            <td class="editButton" valign="middle">
                                                <a class="deleteButton" onclick="return confirm_alert(this);" href=<?php echo config::URL  ?>deleteadmin/Deleteadmin>Delete</a>
                                            </td>
                                         </tr>
                                             <?php else: ?>
                                                <td class="editTitleCenter" valign="top"> 
                                                    <input type="submit" name="submit" value="Update">
                                                </td>
                                             <?php endif ?>
                                          </tr>
                                     </table>
                                 </td>
                            </tr>
                         </table>
                </div>
             </td>
        </tr>
    </table>
    
    <script>
        function confirm_alert(node) {
        return confirm("Are you sure you want to delete this student from the registry?");
        }
    </script>