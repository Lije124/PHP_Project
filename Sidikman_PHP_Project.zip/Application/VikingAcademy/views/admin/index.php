<div id="content" class="content">
    <table>
        <tr>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle" valign="middle">
                            Admins
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addadmin/index"  method="post"> 
                                <button type="submit" id="add_admin" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" height="5"></td>
                    </tr>
                    <tr>
                         <td colspan="2" class="redline"></td>
                    </tr>
                    <tr>
                         <td colspan="2" height="10"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            
                            <table>
                                <?php if ($_SESSION["role"] == 'Owner') { ?>
                                        <tr>
                                            <td class='navimg'><a href="<?php echo config::URL ?>Manager/index/1"><img class="img_tt" src="<?php echo config::URL ?>public/images/admins/<?php echo $this->adminData[0]['Image'] ?>" alt="Manager Image"></a></td>
                                            <td class='navname'><a href="<?php echo config::URL ?>Manager/index/1"><span class="itemlinks"><?php echo $this->adminData[0]['Name'] ?></span></a></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" height="10"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" class="redline"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" height="10"></td>
                                        </tr>
                                <?php } ?>
                                          
                                <?php foreach($this->adminData as $row){ 
                                    if ($row['ID'] > 1) { ?>
                                        <tr>
                                            <td class='navimg'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/admins/<?php echo $row['Image'] ?>" alt="Manager Image"></a></td>
                                            <td class='navname'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" height="10"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" class="redline"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" height="10"></td>
                                        </tr>
                                  
                                <?php } } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            
            <td class="redvert"></td>
            <td class="admin_home" valign="middle">
                   <?php if (Session::get('status') == 'admindeleted') { ?>
                        <div class="asgardbox2" valign="middle">
                        <p class="mainTitle">Asgard Office</p>
                        <p class="mainIndex">Admin ID <span class="black"><?php echo Session::get('admin') ?> was deleted</span></p>
                        <p class="mainIndex">Number of Administrators: <span class="black"><?php echo count($this->adminData) ?></span></p>
                        </div>
                    <?php Session::remove('admin'); Session::set('status', 'neutral'); } else { ?>
                        <div class="asgardbox" valign="middle">
                        <p class="mainTitle">Asgard Office</p>
                        <p class="mainIndex">Number of Administrators: <span class="black"><?php echo count($this->adminData) ?></span></p>
                        </div>
                    <?php } ?>
            </td>
        </tr>
    </table>