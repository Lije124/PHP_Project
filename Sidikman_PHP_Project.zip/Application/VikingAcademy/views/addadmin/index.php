<div id="content" class="content">
    <table>
        <tr>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Admins
                        </td>
                        <td class="navadd">
                            <?php if (SESSION::get('role') != 'Sales'): ?>
                            <form action="<?php echo config::URL  ?>addadmin/index"  method="post"> 
                                <button type="submit" id="add_admin" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                            <?php endif ?>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" height="5"></td>
                    </tr>
                    <tr>
                         <td colspan="2" class="redline"></td>
                    </tr>
                    <tr>
                         <td colspan="2" height="10"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            
                            <table>
                                 
                               <?php foreach($this->adminData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/admins/<?php echo $row['Image'] ?>" alt="Administrator Image"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr> 
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            
            <td class="redvert"></td>
            <td class="admin_home" valign="middle">
                <div class="adminaddbox">
                        <table>
                            <tr>
                                <td colspan="3">
                                     <p class="itemtitle1">Add an Administrator</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" class="line"></td>
                            </tr>
                            <tr>
                                <td colspan="3" height="20"></td>
                            </tr>
                            <form action="<?php echo config::URL ?>Addadmin/addAdmin"  method="post" enctype="multipart/form-data">  
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Name&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="inputcell"><input class="viking" type="text" name="adminname"></td>
                                <td class="imagecell" rowspan="5" valign="top"><label class="itemlabel">Image</label><br>
                                    <div id="thumbnail">
                                        <img src="<?php echo config::URL ?>public/images/img_holder.jpg" alt="Add an image">
                                    </div>
                                    <label class="upload" for="upload">Select File</label><input type="file" name="uploadimage" id="upload"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Role&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="inputcell">
                                    <?php if (SESSION::get('role') == 'Owner'): ?>
                                        <select class="viking selectrole" type="text" name="adminrole">
                                            <option value="">Select...</option>
                                            <option value="Manager">Manager</option>
                                            <option value="Sales">Sales</option>
                                        </select>
                                    <?php else: ?>
                                        <select class="viking selectrole" type="text" name="adminrole">
                                            <option value="">Select...</option>
                                            <option value="Sales">Sales</option>
                                        </select>
                                    <?php endif ?>
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Phone&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="inputcell"><input class="viking" type="text" name="adminphone"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"><label class="itemlabel">Email&nbsp;&nbsp;&nbsp;</label></td>
                                <td class="inputcell"><input class="viking" type="text" name="adminemail"></td>
                            </tr>
                            <tr>
                                <td class="labelcell"></td>
                                <td class="inputcell"></td>
                            </tr>

                             <tr>
                                <td colspan="3" class="addAdminButton">
                                <input type="submit" name="submit" value="Add">
                                </td>
                            </tr>
                             </form>
                         </table>
                    </div>
                </div>
             </td>
        </tr>
    </table>