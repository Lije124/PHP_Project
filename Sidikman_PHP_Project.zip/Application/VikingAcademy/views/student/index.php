<div id="content" class="content">
    <table>
        <tr>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Courses
                        </td>
                        <td class="navadd">
                            <?php if (SESSION::get('role') != 'Sales'): ?>
                            <form action="<?php echo config::URL  ?>addcourse/index/"  method="post"> 
                                <button type="submit" id="add_course" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                            <?php endif ?>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" height="5"></td>
                    </tr>
                    <tr>
                         <td colspan="2" class="redline"></td>
                    </tr>
                    <tr>
                         <td colspan="2" height="10"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            
                            <table>
                                 
                               <?php foreach($this->courseData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Course/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/courses/<?php echo $row['Image'] ?>" alt="CourseImage"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Course/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            <td class="redvert"></td>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Students
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addstudent/index/"  method="post"> 
                                <button type="submit" id="add_student" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td height="5" colspan="2"></td>
                    </tr>
                    <tr>
                        <td class="redline" colspan="2"></td>
                    </tr>
                    <tr>
                        <td height="10" colspan="2"</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            <table>

                               <?php foreach($this->studentData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Student/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/students/<?php echo $row['Image'] ?>" alt="StudentImage"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Student/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            <td class="redvert"></td>
            <td class="main_home" valign="middle">
                <div class="itembox">
                    <div class="editStudent">
                        <?php foreach($this->thisStudent as $row){ ?>
                        <table>
                            <tr>
                            <td class="itemTitle">
                              <p class="itemtitle1">Student</p>  
                            </td>
                            <td class="itemButton" valign="top">
                                <form action="<?php echo config::URL  ?>editstudent/index/<?php echo $row['ID']; ?>"  method="post"> 
                                <input class="loginput" type="submit" value="Edit">
                                  </form>
                            </td>
                            </tr>
                        </tr>

                        </table>
                    </div>
                    <table class="redborder">
                      
                        <tr>
                             <td class="itemimg redborder">
                                <img class="img_full" src="<?php echo config::URL ?>public/images/students/<?php echo $row['Image']; ?>" alt="Student Image">
                            </td>
                            <td class="coursedesc redborder">
                                <p class="desc1"><?php echo $row['Name'] ?></p>
                                <p class="desc2"><?php echo $row['Phone'] ?></p>
                                <p class="desc2"><?php echo $row['Email'] ?></p>
                            </td>
                        </tr>
                       
                    </table>
                     <?php } ?>
                   <div class="itemtitle">Enrolled Courses</div>

                    <table class="redborder">
                        
                        <?php foreach ($this->registryData as $row) { ?>
                                    <tr>
                                        <td class="listimg redborder">
                                            <a href="<?php echo config::URL ?>Course/index/<?php echo $row['CourseID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/courses/<?php echo $row['Image'] ?>" alt="Course Image"></a>
                                        </td>
                                        <td class="listname redborder">
                                            <a href="<?php echo config::URL ?>Course/index/<?php echo $row['CourseID'] ?>"><p class="desc"><?php echo $row['Name'] ?></p></a>
                                        </td>
                                    </tr>
                        <?php } ?>
                     </table>
                </div>
           </td>
        </tr>
    </table>
    
    