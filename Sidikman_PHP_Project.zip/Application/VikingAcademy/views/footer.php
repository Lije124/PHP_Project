
</div>
<div class="redline"></div>
</div>
<script src="<?php echo config::URL  ?>public/js/thumbnail.js"></script>
</body>
</html>
