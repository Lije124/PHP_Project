<h1>Calc Error</h1>

<?php echo $this->error_msg ?>