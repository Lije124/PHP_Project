<h1>Error occurred</h1>

<h4>Error details:</h4>
<hr>
<?php echo $this->error_msg ?>

