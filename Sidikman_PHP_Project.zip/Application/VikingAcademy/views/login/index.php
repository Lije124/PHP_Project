<div id="content" class="content">
    <div class="logform">
    <form action="<?php echo config::URL  ?>login/authenticate"  method="post"> 
        <table>
            <tr>
                <td class="labelcell"><label class="loglabel">Username&nbsp;&nbsp;</label></td>
                <td class="labelcell"><input type="text" name="login"><br></td></tr>
            <tr>
                <td class="labelcell"><label class="loglabel">Password&nbsp;&nbsp;</label></td>
                <td class="labelcell"><input type="password" name="password"></td></tr>
            <tr>
                <td colspan="2" class="logbutton"><input class="loginput" type="submit" value="Login"></td>
            </tr>
        </table>
    </form>
    </div>

