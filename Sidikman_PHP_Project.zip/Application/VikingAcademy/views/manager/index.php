<div id="content" class="content">
    <table>
        <tr>
            <td class="navbar" valign="top">
                <table>
                    <tr>
                        <td class="navtitle">
                            Admins
                        </td>
                        <td class="navadd">
                            <form action="<?php echo config::URL  ?>addstudent/index/"  method="post"> 
                                <button type="submit" id="add_student" value="Add"><i class="delInv glyphicon glyphicon-plus"></i></button>
                            </form>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" height="5"></td>
                    </tr>
                    <tr>
                         <td colspan="2" class="redline"></td>
                    </tr>
                    <tr>
                         <td colspan="2" height="10"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="navitems">
                            
                            <table>
                                 
                               <?php foreach($this->adminData as $row){ ?>
                                <tr>
                                    <td class='navimg'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><img class="img_tt" src="<?php echo config::URL ?>public/images/admins/<?php echo $row['Image'] ?>" alt="Administrator Image"></a></td>
                                    <td class='navname'><a href="<?php echo config::URL ?>Manager/index/<?php echo $row['ID'] ?>"><span class="itemlinks"><?php echo $row['Name'] ?></span></a></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" class="redline"></td>
                                </tr>
                                <tr>
                                    <td colspan="2" height="10"></td>
                                </tr>
                                <?php } ?>
                            </table>
                            </div>
                        </td>  
                     </tr>
                </table>
            </td>
            <td class="redvert"></td>
            <td class="admin_home" valign="middle">
                <div class="adminbox">
                    <div class="editAdmin">
                        <?php foreach($this->thisAdmin as $row){ ?>
                        <table>
                            <tr>
                            <td class="itemTitle">
                              <p class="itemtitle1">Administrator</p>  
                            </td>
                            <td class="itemButton" valign="top">
                                <form action="<?php echo config::URL  ?>editadmin/index/<?php echo $row['ID']; ?>"  method="post"> 
                                    <input class="loginput" type="submit" value="Edit">
                                </form>   
                            </td>
                            </tr>
                        </table>
        
                    </div>
                    <table class="redborder">
                        
                       
                        <tr>
                             <td class="itemimg redborder">
                                <img class="img_full" src="<?php echo config::URL ?>public/images/admins/<?php echo $row['Image']; ?>" alt="Administrator Image">
                            </td>
                            <td class="coursedesc redborder">
                                <p class="desc1"><?php echo $row['Name'] ?></p>
                                <p class="desc2"><?php echo $row['Role'] ?></p>
                                <p class="desc2"><?php echo $row['Phone'] ?></p>
                                <p class="desc2"><?php echo $row['Email'] ?></p>
                            </td>
                        </tr>
                        <?php } ?>
                    </table>
                </td>
        </tr>
    </table>



