<!DOCTYPE html>
<html>
    <head>
        <title>Viking Academy</title>
        <link rel="stylesheet" href="<?php echo config::URL ?>public/css/main.css">
        <link rel="stylesheet" href="<?php echo config::URL ?>public/bootstrap-3.3.7-dist/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <div class="banner">
                <table>
                    <tr>
                        <td class="logo"><img src="<?php echo config::URL ?>public/images/vu_logo_t.jpg" alt="Viking Academy" /></td>
                        <td class="title"><span class="titlefont">Viking Academy</span><br><span class="titlefont2">&nbsp;&nbsp;Lore from Yore</span></td>
                        <td class="runes" valign="middle"><img src="<?php echo config::URL ?>public/images/runes.jpg" alt="Viking Runes" /></td>
                    </tr>
                </table>
                
             </div>
            <div class="redline"></div>
        <?php if (SESSION::get('loggedIn') == true): ?>
        <div class="menu" id="header">
            <table>
                <tr>
                    <td class="links">
                        <a href="<?php echo config::URL ?>academy">Academy</a>&nbsp;&nbsp;
                        <?php if (SESSION::get('role') != 'Sales'): ?>
                            <a href="<?php echo config::URL ?>admin">Administration</a>
                        <?php endif ?>
                        &nbsp;&nbsp;
                        <a href="<?php echo config::URL ?>help">Help</a>
                    </td>
                    <td class="user">
                        <span><?php echo SESSION::get('name') ?>,&nbsp;<?php echo SESSION::get('role') ?><br>
                            <?php if (SESSION::get('loggedIn')): ?>
                                <a href="<?php echo config::URL ?>login/logout">Logout</a>
                            <?php else: ?>
                                <a href="<?php echo config::URL ?>login/login">Login</a>
                            <?php endif ?>
                        </span> 
                    </td>
                    <td class="userimg">
                        <img class="img_log" src="<?php echo config::URL ?>public/images/admins/<?php echo SESSION::get('image') ?>" alt="User Image" />
                    </td>
                </tr>
            </table>
        </div>

        <div class="redline"></div>
        <?php endif ?>
 
      
          
            

 



