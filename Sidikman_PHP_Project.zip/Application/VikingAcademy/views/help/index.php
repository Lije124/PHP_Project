<div class="contact">
    <img src="<?php echo config::URL ?>public/images/help.jpg" alt="Contact Us" />
           

